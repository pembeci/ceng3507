def index():
    images = db().select(db.image.ALL, orderby=db.image.title)
    return dict(images=images)

def account():
    account_id = request.args(0,cast=int)
    if (user and user.id == account_id):
       account = user
    else:   
       account = db.user(account_id) or redirect(URL('index'))
    return dict(account=account)
    
def show():
    global user
    image_id = request.args(0,cast=int)
    image = db.image(image_id) or redirect(URL('index'))
    db.post.image_id.default = image.id
    if user != None:
        form = FORM("Your comment", BR(), 
              TEXTAREA(_name='comment', _cols= 40, _rows=5, requires=IS_NOT_EMPTY()),
              INPUT(_type='submit', _value="SEND COMMENT"))
        if form.process().accepted:
          db.post.insert(image_id=image_id, 
                         author=user.id,
                         body = form.vars.comment
                        )
          response.flash = 'your comment is posted'
    else: 
        form = None        
    comments = db( (db.post.image_id==image.id) &
                   (db.post.author == db.user.id)).select()
    return dict(image=image, comments=comments, form=form)
    
def comments():
    name = request.args(0)
    comments = db(db.post.author==name).select() or redirect(URL('index'))
    return dict(comments=comments, name=name)

def download():
    return response.download(request, db)    

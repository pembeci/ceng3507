def index():
    images = db().select(db.image.ALL, orderby=db.image.title)
    return dict(images=images)

def account():
    account_id = request.args(0,cast=int)
    if (user and user.id == account_id):
       account = user
    else:   
       account = db.user(account_id) or redirect(URL('index'))
    return dict(account=account)
    
def show():
    image = db.image(request.args(0,cast=int)) or redirect(URL('index'))
    db.post.image_id.default = image.id
    form = SQLFORM(db.post)
    if form.process().accepted:
        response.flash = 'your comment is posted'
    comments = db(db.post.image_id==image.id).select()
    return dict(image=image, comments=comments, form=form)
    
def comments():
    name = request.args(0)
    comments = db(db.post.author==name).select() or redirect(URL('index'))
    return dict(comments=comments, name=name)

def download():
    return response.download(request, db)    
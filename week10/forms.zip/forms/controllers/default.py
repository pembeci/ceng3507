# -*- coding: utf-8 -*-
# this file is released under public domain and you can use without limitations

#########################################################################
## This is a sample controller
## - index is the default action of any application
## - user is required for authentication and authorization
## - download is for downloading files uploaded in the db (does streaming)
#########################################################################

from gluon.storage import Storage

def index():
    """
    example action using the internationalization operator T and flash
    rendered by views/default/index.html or views/generic.html

    if you need a simple wiki simply replace the two lines below with:
    return auth.wiki()
    """
    response.flash = T("Hello World")
    return dict(message=T('Welcome to web2py!'))

def new_account():
   errors = Storage()   
   if request.vars:  # postback
      form_data = request.vars
      form_data.gender = form_data.gender or ""
      form_data.hobby = form_data.hobby or []
      if type(form_data.hobby) == str: form_data.hobby = [form_data.hobby]
      if form_data.name == "":
        errors.name = "You can't leave this field empty"
      if len(form_data.pw1) < 8:  
        errors.pw = "At least 8 characters in password"
      elif form_data.pw1 != form_data.pw2:
        errors.pw = "Passwords don't match"      
   else:
      form_data = Storage()  
      form_data.name = form_data.pw1 = form_data.pw2 = form_data.bio = ""
      form_data.gender = "M"
      form_data.hobby = []
   if errors or not request.vars:
      return dict(data = form_data, errors=errors)
   else:      
      return "Success"
      



def another():
   data = request.vars
   data.gender = data.gender or ""
   data.hobby = data.hobby or []
   if type(data.hobby) == str: data.hobby = [data.hobby]   
   return dict(data=request.vars)
   
def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/manage_users (requires membership in
    http://..../[app]/default/user/bulk_register
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    """
    return dict(form=auth())


@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)


def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    return service()



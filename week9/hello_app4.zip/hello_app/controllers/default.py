# -*- coding: utf-8 -*-
# this file is released under public domain and you can use without limitations

#########################################################################
## This is a sample controller
## - index is the default action of any application
## - user is required for authentication and authorization
## - download is for downloading files uploaded in the db (does streaming)
#########################################################################
 
def capitalize(title):
   words = title.split()
   words = [word.capitalize() for word in words]
   return " ".join(words)

authors_data = [
             { 'id': 1, 'name': "Orhan Pamuk", "bio": "Ferit Orhan Pamuk (generally known simply as Orhan Pamuk; born 7 June 1952) is a Turkish novelist, screenwriter, academic and recipient of the 2006 Nobel Prize in Literature. One of Turkey's most prominent novelists, his work has sold over eleven million books in sixty languages, making him the country's best-selling writer.",
               'img': "pamuk.jpg" },
             { 'id': 3, 'name': "John Steinbeck", "bio": "John Ernst Steinbeck, Jr. (February 27, 1902 – December 20, 1968) was an American author of twenty-seven books, including sixteen novels, six non-fiction books, and five collections of short stories. He is widely known for the comic novels Tortilla Flat (1935) and Cannery Row (1945), the multi-generation epic East of Eden (1952), and the novellas Of Mice and Men (1937) and The Red Pony (1937). The Pulitzer Prize-winning The Grapes of Wrath (1939),[2] widely attributed to be part of the American literary canon,[3] is considered Steinbeck's masterpiece. In the first 75 years since it was published, it sold 14 million copies.",
               'img': "John_Steinbeck_1962.jpg" },                    
             { 'id': 2, 'name': "Ursula K. LeGuin", "bio": "Ursula Kroeber Le Guin (US /ˈɜrsələ ˈkroʊbər ləˈɡwɪn/; born October 21, 1929) is an American author of novels, children's books, and short stories, mainly in the genres of fantasy and science fiction. She has also written poetry and essays. First published in the 1960s, her work has often depicted futuristic or imaginary alternative worlds in politics, natural environment, gender, religion, sexuality and ethnography.",
               'img': "ukl.jpg" }
          ]
book_data = [ { 'author': 1, 
                'title': "My Name is Red",
                'price': 24,
                'year': 2003,
                'publisher': "İletişim Y."
                  },
                  { 'author': 1, 
                'title': "Black Book",
                'price': 45,
                'year': 1992,
                'publisher': "İletişim Y."
                  },
                 { 'author': 1, 
                'title': "White Castle",
                'price': 12,
                'year': 1995,
                'publisher': "YKY"
                  },
                 { 'author': 2, 
                'title': "Dispossessed",
                'price': 34,
                'year': 1974,
                'publisher': "Metis"
                  },
                  { 'author': 2, 
                'title': "A Wizard of Earthsea",
                'price': 12,
                'year': 1978,
                'publisher': "Metis"
                  },
             { 'author': 3, 
                'title': "Of Mice and men",
                'price': 6,
                'year': 1958,
                'publisher': "İletişim"
                  }                   
                ] 

def find_author(book):
   global authors_data
   for author in authors_data:
     if book["author"] == author["id"]:
       return author
   return None
                      
def index():
    return dict(page_title="CENG BOOK CAFE"
                )

def contact():  
    return dict(page_title="Contact Us")

def authors():
    global book_data          
    authors_list = dict()
    for book in book_data:
       author_obj = find_author(book)
       author_name = author_obj["name"]
       if author_name in authors_list:
          authors_list[author_name] = (authors_list[author_name][0]+1, author_obj['id'])
       else:   
          authors_list[author_name] = (1, author_obj['id'])
    print(authors_list)      
    return dict(page_title="Authors", authors=authors_list)

def about():
    return dict(page_title="About us")
    
def book():
    global book_data                 
    k = int(request.args[1])
    book = book_data[k]
    book['title'] = capitalize(book['title'])
    return dict(page_title=book["title"] + (" (%dTL)" % book['price']), book=book, id=k)

def author():
    global authors_data                 
    k = int(request.args[1])
    author_obj = None
    for author in authors_data:
      if k == author["id"]:
         author_obj = author
         break
    if author_obj == None:
       # raise HTTP(404, 'Page not found', test='hello') 
       redirect(URL("error_page", vars=dict(url=request.env.path_info)))    
    return dict(page_title=author_obj["name"], author=author_obj)

def error_page():
    return dict(page_title="Error")

def book_list():
    global book_data
    books = []
    for book in book_data:
       book['title'] = capitalize(book['title'])
       book["author_name"] = find_author(book)['name']
       books.append(book)
    return dict(page_title="All Books", books=books)
       
def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/manage_users (requires membership in
    http://..../[app]/default/user/bulk_register
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    """
    return dict(form=auth())


@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)


def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    return service()

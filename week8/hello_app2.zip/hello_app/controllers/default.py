# -*- coding: utf-8 -*-
# this file is released under public domain and you can use without limitations

#########################################################################
## This is a sample controller
## - index is the default action of any application
## - user is required for authentication and authorization
## - download is for downloading files uploaded in the db (does streaming)
#########################################################################

book_data = [ { 'author': 'Orhan Pamuk', 
                'title': "My Name is Red",
                'price': 24,
                'year': 2003,
                'publisher': "İletişim Y."
                  },
                  { 'author': 'Orhan Pamuk', 
                'title': "Black Book",
                'price': 45,
                'year': 1992,
                'publisher': "İletişim Y."
                  },
                 { 'author': 'Orhan Pamuk', 
                'title': "White Castle",
                'price': 12,
                'year': 1995,
                'publisher': "YKY"
                  },
                 { 'author': 'Ursula K. LeGuin', 
                'title': "Dispossessed",
                'price': 34,
                'year': 1974,
                'publisher': "Metis"
                  },
                  { 'author': 'Ursula K. LeGuin', 
                'title': "A Wizard of Earthsea",
                'price': 12,
                'year': 1978,
                'publisher': "Metis"
                  }                     
                ] 
                
def index():
   
    return dict(name = 'izzet', 
                age=48,
                nums1 = [1,3,5,7, 9, 11,15,19,250],
                nums2 = [4,14,11, 13, 26]
                )

def contact():
    return "Send me an e-mail"
 
def book():
    global book_data                 
    import random
    k = random.randint(0,2)    
    # print(k)
    # print(request.args)
    k = int(request.args[0])
    # print(k)
    return dict(book=book_data[k], id=k)

def book_list():
    global book_data
    return dict(books=book_data)
       
def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/manage_users (requires membership in
    http://..../[app]/default/user/bulk_register
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    """
    return dict(form=auth())


@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)


def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    return service()

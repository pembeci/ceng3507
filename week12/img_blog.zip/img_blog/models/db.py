db = DAL("sqlite://storage.sqlite")

db.define_table('user',
  Field('username', unique=True, required=True),
  Field('password', 'password', required=True),
  Field('role'),
  Field('email'),
  Field('login_time', 'integer') 
)
  
db.user.email.requires = IS_EMAIL()
# db.user.login.writable = db.user.login.readable = False
  
db.define_table('image',
   Field('title', unique=True),
   Field('vote', 'integer'),
   Field('file', 'upload'),
   format = '%(title)s [score=%(vote)s]')

db.define_table('post',
   Field('image_id', 'reference image'),
   Field('author'),
   Field('email'),
   Field('body', 'text'))

db.image.title.requires = IS_NOT_IN_DB(db, db.image.title)
db.image.vote.requires = IS_INT_IN_RANGE(1,10)

db.post.image_id.requires = IS_IN_DB(db, db.image.id, '%(title)s')
db.post.author.requires = IS_NOT_EMPTY()
db.post.email.requires = IS_EMAIL()
db.post.body.requires = IS_NOT_EMPTY()

db.post.image_id.writable = db.post.image_id.readable = False

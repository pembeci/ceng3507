def signup():
   # db.user.truncate()
   import hashlib
   import time
   form = FORM(
     'Username', INPUT(_name='username', requires=[IS_NOT_EMPTY(), IS_NOT_IN_DB(db,db.user.username)]), BR(),
     'Password', INPUT(_name='pw1', _type='password', label='Password'), BR(),
     'Paswword2', INPUT(_name='pw2', _type='password', label='Confirm password',
            requires=IS_EQUAL_TO(request.vars.pw1, "don't match")), BR(),
     'Email', INPUT(_name='email', requires=IS_EMAIL()), BR(),
     INPUT(_type='submit'),
     _id="loginform", _class="bootstrapform"
   )
   if form.process().accepted:
     db.user.insert(username=form.vars.username, 
                    password=hashlib.md5(form.vars.pw1).hexdigest(),
                    email = form.vars.email,
                    login_time = int(time.time()),
                    role = "rookie"
                    )
     return "Save the record"
   return dict(form = form)